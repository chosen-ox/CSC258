You can just use `cargo run` to run my code.
To see the test part, see `main.rs`
	
